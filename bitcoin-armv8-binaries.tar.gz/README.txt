Bitcoin Core ArmV8
Compiled for Ubuntu 16.04 (aarch64)
Cortex-a53 optimised

Requires at least 600mb free ram, preferable with have 1gb and swap memory available.

Require software dependencies to be installed as detailed in doc/build-unix.md and here

sudo add-apt-repository ppa:bitcoin/bitcoin

sudo apt-get update

sudo apt-get install build-essential libtool autotools-dev automake pkg-config bsdmainutils python3 libssl-dev libevent-dev libboost-system-dev libboost-filesystem-dev libboost-chrono-dev libboost-test-dev libboost-thread-dev software-properties-common libdb4.8-dev  libdb4.8++-dev libzmq3-dev

Try running bitcoin-cli

./bitcoin-cli

If incompatible platform or missing libraries it give error message and fail. Otherwise exits with rpc info missing notice. You can start bitcoind and it will start syncing, which will take a long time. 

Blockchain (200+gb) torrent download (much faster). https://getbitcoinblockchain.com/

Alternatively if you do not intend to run full not, just a wallet a pruned Bitcoin Blockchain (approx 3gb download) is available see https://github.com/rollmeister/bitcoinle-core-armv8 (not directly related to Bitcoin no software there for you if you are only after Bitcoin software) readme.me for details.
